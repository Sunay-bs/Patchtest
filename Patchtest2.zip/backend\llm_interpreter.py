import os
from typing import Dict, List
import openai
from dotenv import load_dotenv

load_dotenv()

class LLMInterpreter:
    def __init__(self):
        # Force the API key everywhere
        self.api_key = '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'
        import openai, os
        openai.api_key = self.api_key
        os.environ['OPENAI_API_KEY'] = self.api_key
        print(f"[DEBUG] Using OpenAI API key: {self.api_key}")

    def _generate_vulnerability_prompt(self, services: List[Dict]) -> str:
        """Generate a prompt for vulnerability analysis."""
        prompt = "Analyze these services for potential vulnerabilities:\n\n"
        for service in services:
            prompt += f"Service: {service['service']}\n"
            prompt += f"Version: {service['version']}\n"
            prompt += f"Product: {service['product']}\n"
            prompt += f"Running on: {service['ip']}:{service['port']}\n\n"
        prompt += "\nPlease identify:\n"
        prompt += "1. Known vulnerabilities for these versions\n"
        prompt += "2. Risk level (Critical/High/Medium/Low)\n"
        prompt += "3. Recommended patches or mitigations\n"
        return prompt

    def analyze_vulnerabilities(self, services: List[Dict]) -> Dict:
        """
        Analyze vulnerabilities using OpenAI's GPT model.
        For hackathon/demo purposes, returns mock data if API key is not set.
        """
        if self.api_key == 'dummy-key':
            return self._mock_vulnerability_analysis(services)
        try:
            prompt = self._generate_vulnerability_prompt(services)
            import openai
            # If quota exceeded, fallback to mock
            try:
                response = openai.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "You are a cybersecurity expert analyzing vulnerabilities in network services."},
                        {"role": "user", "content": prompt}
                    ]
                )
                return self._parse_llm_response(response.choices[0].message.content, services)
            except Exception as e:
                if 'insufficient_quota' in str(e) or '429' in str(e):
                    print("OpenAI quota exceeded, using mock data.")
                    return self._mock_vulnerability_analysis(services)
                raise e
        except Exception as e:
            print(f"Error calling OpenAI API: {str(e)}")
            return self._mock_vulnerability_analysis(services)

    def _mock_vulnerability_analysis(self, services: List[Dict]) -> Dict:
        """Generate mock vulnerability analysis for demo purposes."""
        mock_results = []
        risk_levels = ['Critical', 'High', 'Medium', 'Low']
        risk_summary = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
        for idx, service in enumerate(services):
            vulnerabilities = []
            # Simulate 2 vulnerabilities per service
            for v in range(2):
                risk_level = risk_levels[(idx + v) % len(risk_levels)]
                if risk_level == 'Critical':
                    risk_summary['critical'] += 1
                elif risk_level == 'High':
                    risk_summary['high'] += 1
                elif risk_level == 'Medium':
                    risk_summary['medium'] += 1
                else:
                    risk_summary['low'] += 1
                vulnerabilities.append({
                    'name': f'Mock vulnerability {v+1} in {service["service"]}',
                    'risk_level': risk_level,
                    'cve_id': f'CVE-2023-{1000+idx*10+v}',
                    'description': f'Potential {risk_level.lower()} risk in {service["service"]} version {service["version"]}',
                    'recommendation': f'Apply latest patches and follow vendor security advisories for {service["service"]}.'
                })
            mock_result = {
                'service_info': service,
                'vulnerabilities': vulnerabilities,
                'risk_score': 9.0 if 'Critical' in [v['risk_level'] for v in vulnerabilities] else 7.0,
                'patch_available': True,
                'patch_steps': [
                    f'1. Backup current {service["service"]} configuration',
                    f'2. Download latest stable version',
                    f'3. Stop {service["service"]} service',
                    f'4. Install updates',
                    f'5. Restore configuration',
                    f'6. Restart service'
                ]
            }
            mock_results.append(mock_result)
        return {
            'analysis_results': mock_results,
            'total_vulnerabilities': sum(len(r['vulnerabilities']) for r in mock_results),
            'risk_summary': risk_summary
        }

    def _parse_llm_response(self, response: str, services: List[Dict]=None) -> Dict:
        """Parse the LLM response into structured data."""
        import json
        try:
            parsed = json.loads(response)
            return parsed
        except Exception:
            # Fallback: wrap the raw response in a dict for the report
            # If services are provided, generate a mock-like structure for all
            if services:
                return self._mock_vulnerability_analysis(services)
            return {
                'analysis_results': [
                    {
                        'service_info': {},
                        'vulnerabilities': [
                            {
                                'name': 'LLM Analysis',
                                'risk_level': 'Unknown',
                                'cve_id': '',
                                'description': response,
                                'recommendation': 'See above.'
                            }
                        ],
                        'risk_score': None,
                        'patch_available': False,
                        'patch_steps': []
                    }
                ],
                'total_vulnerabilities': 1,
                'risk_summary': {
                    'critical': 0,
                    'high': 0,
                    'medium': 0,
                    'low': 0
                }
            }

    def natural_language_query(self, query: str, vulnerability_data: Dict) -> str:
        """Handle natural language queries about vulnerabilities."""
        try:
            prompt = f"""Given this vulnerability data:
            {str(vulnerability_data)}
            
            Answer this question: {query}
            """
            
            if self.api_key == 'dummy-key':
                return "This is a mock response to your query. In production, this would use the OpenAI API to provide specific answers about the vulnerabilities."
            
            import openai
            try:
                response = openai.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "You are a cybersecurity expert helping to interpret vulnerability scan results."},
                        {"role": "user", "content": prompt}
                    ]
                )
                return response.choices[0].message.content
            except Exception as e:
                if 'insufficient_quota' in str(e) or '429' in str(e):
                    print("OpenAI quota exceeded, using mock response.")
                    return "OpenAI quota exceeded. This is a mock response."
                raise e
        except Exception as e:
            return f"Error processing query: {str(e)}"
