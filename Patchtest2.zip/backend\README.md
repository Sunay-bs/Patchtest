# Vulnerability Patch Management System - Backend

## Overview
This is the backend component of the Vulnerability Patch Management System, built using Flask. It provides APIs for managing vulnerabilities, patches, and scan results.

## Setup Instructions

1. **Clone the repository:**
   ```
   git clone <repository-url>
   cd vulnerability-patch-management-system/backend
   ```

2. **Create a virtual environment:**
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. **Install dependencies:**
   ```
   pip install -r requirements.txt
   ```

4. **Run the application:**
   ```
   python app.py
   ```

   The application will start on `http://127.0.0.1:5000`.

## API Endpoints

- **Upload Scan File**
  - **Endpoint:** `/api/upload`
  - **Method:** POST
  - **Description:** Upload a scan file for processing.

- **Query Vulnerabilities**
  - **Endpoint:** `/api/vulnerabilities`
  - **Method:** GET
  - **Description:** Retrieve a list of vulnerabilities.

- **Generate Report**
  - **Endpoint:** `/api/report`
  - **Method:** GET
  - **Description:** Generate a report based on the uploaded scan data.

## Usage
After setting up the backend, you can interact with the API using tools like Postman or through the frontend interface.

## Contributing
Feel free to submit issues or pull requests for improvements and bug fixes. Please ensure to follow the coding standards and include tests for new features.