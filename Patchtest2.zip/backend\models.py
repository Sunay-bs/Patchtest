from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Vulnerability(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    severity = db.Column(db.String(50), nullable=False)
    date_discovered = db.Column(db.DateTime, nullable=False)

class Patch(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vulnerability_id = db.Column(db.Integer, db.ForeignKey('vulnerability.id'), nullable=False)
    patch_version = db.Column(db.String(100), nullable=False)
    release_date = db.Column(db.DateTime, nullable=False)
    description = db.Column(db.Text, nullable=True)

class ScanResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    scan_date = db.Column(db.DateTime, nullable=False)
    vulnerabilities = db.relationship('Vulnerability', backref='scan_results', lazy=True)