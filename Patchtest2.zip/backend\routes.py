from flask import Blueprint, request, jsonify, send_file
from models import Vulnerability, Patch, ScanResult
from nmap_parser import NmapParser
from llm_interpreter import LLMInterpreter
from report_generator import ReportGenerator
import os
import tempfile
from datetime import datetime

api_routes = Blueprint('api_routes', __name__)

# In-memory store for demo
SCAN_RESULTS = {}
VULNERABILITY_DATA = {}
PATCH_STATUS = {}

@api_routes.route('/upload', methods=['POST'])
def upload_scan():
    file = request.files.get('scan_file')
    if not file:
        return jsonify({'error': 'No file provided'}), 400
    xml_content = file.read().decode('utf-8')
    parser = NmapParser()
    scan_data = parser.parse_xml(xml_content)
    outdated_services = parser.get_outdated_services()
    llm = LLMInterpreter()
    vuln_data = llm.analyze_vulnerabilities(outdated_services)
    # Store results in memory for demo
    SCAN_RESULTS['scan'] = scan_data
    VULNERABILITY_DATA['vulns'] = vuln_data
    # Initialize patch status
    for result in vuln_data['analysis_results']:
        key = f"{result['service_info']['ip']}:{result['service_info']['port']}:{result['service_info']['service']}"
        PATCH_STATUS[key] = 'Pending'
    return jsonify({
        'scan_summary': scan_data,
        'vulnerability_analysis': vuln_data,
        'patch_status': PATCH_STATUS
    }), 200

@api_routes.route('/query', methods=['POST'])
def query_vulnerabilities():
    data = request.json
    query = data.get('query', '')
    llm = LLMInterpreter()
    vuln_data = VULNERABILITY_DATA.get('vulns', {})
    response = llm.natural_language_query(query, vuln_data)
    return jsonify({'response': response}), 200

@api_routes.route('/patch_status', methods=['POST'])
def update_patch_status():
    data = request.json
    key = data.get('key')
    status = data.get('status')
    if key in PATCH_STATUS:
        PATCH_STATUS[key] = status
        return jsonify({'message': 'Status updated'}), 200
    return jsonify({'error': 'Invalid key'}), 400

@api_routes.route('/report', methods=['GET'])
def generate_report():
    format = request.args.get('format', 'html')
    vuln_data = VULNERABILITY_DATA.get('vulns', {})
    report_gen = ReportGenerator()
    if format == 'pdf':
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
            report_path = tmp.name
        report_gen.generate_pdf_report(vuln_data, report_path)
        return send_file(report_path, as_attachment=True, download_name='vuln_report.pdf')
    else:
        html_report = report_gen.generate_html_report(vuln_data)
        return html_report, 200, {'Content-Type': 'text/html'}

@api_routes.route('/status', methods=['GET'])
def get_patch_status():
    return jsonify(PATCH_STATUS), 200