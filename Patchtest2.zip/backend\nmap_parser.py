import xml.etree.ElementTree as ET
import xmltodict
from typing import Dict, List

class NmapParser:
    def __init__(self):
        self.scan_results = {}

    def parse_xml(self, xml_content: str) -> Dict:
        """Parse NMAP XML scan results."""
        try:
            scan_dict = xmltodict.parse(xml_content)
            hosts = []
            
            if 'nmaprun' in scan_dict and 'host' in scan_dict['nmaprun']:
                raw_hosts = scan_dict['nmaprun']['host']
                # Handle single host case
                if not isinstance(raw_hosts, list):
                    raw_hosts = [raw_hosts]
                
                for host in raw_hosts:
                    host_info = {
                        'ip': host.get('address', {}).get('@addr', 'unknown'),
                        'services': []
                    }
                    
                    if 'ports' in host and 'port' in host['ports']:
                        ports = host['ports']['port']
                        if not isinstance(ports, list):
                            ports = [ports]
                            
                        for port in ports:
                            if 'service' in port:
                                service_info = {
                                    'port': port.get('@portid', 'unknown'),
                                    'service': port['service'].get('@name', 'unknown'),
                                    'version': port['service'].get('@version', 'unknown'),
                                    'product': port['service'].get('@product', 'unknown'),
                                    'state': port.get('state', {}).get('@state', 'unknown')
                                }
                                host_info['services'].append(service_info)
                    
                    hosts.append(host_info)
            
            self.scan_results = {
                'hosts': hosts,
                'total_hosts': len(hosts),
                'timestamp': scan_dict['nmaprun'].get('@startstr', 'unknown')
            }
            
            return self.scan_results
            
        except Exception as e:
            raise Exception(f"Error parsing NMAP XML: {str(e)}")

    def get_outdated_services(self) -> List[Dict]:
        """Extract services that might be outdated based on version information."""
        outdated_services = []
        for host in self.scan_results.get('hosts', []):
            for service in host.get('services', []):
                if service['version'] != 'unknown':
                    outdated_services.append({
                        'ip': host['ip'],
                        'service': service['service'],
                        'version': service['version'],
                        'product': service['product'],
                        'port': service['port']
                    })
        return outdated_services

    def get_service_summary(self) -> Dict:
        """Generate a summary of all services found."""
        summary = {
            'total_services': 0,
            'open_ports': 0,
            'unique_services': set(),
            'services_by_host': {}
        }
        
        for host in self.scan_results.get('hosts', []):
            ip = host['ip']
            summary['services_by_host'][ip] = []
            
            for service in host.get('services', []):
                summary['total_services'] += 1
                if service['state'] == 'open':
                    summary['open_ports'] += 1
                summary['unique_services'].add(service['service'])
                summary['services_by_host'][ip].append(service)
        
        summary['unique_services'] = list(summary['unique_services'])
        return summary
