from datetime import datetime
from typing import Dict
import os
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

class ReportGenerator:
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            spaceAfter=30
        )

    def generate_pdf_report(self, data: Dict, output_path: str) -> str:
        """Generate a PDF report from vulnerability analysis data."""
        doc = SimpleDocTemplate(output_path, pagesize=letter)
        story = []

        # Title
        title = Paragraph("Vulnerability Analysis Report", self.title_style)
        story.append(title)
        story.append(Spacer(1, 12))

        # Summary
        summary = [
            ["Total Vulnerabilities", str(data.get('total_vulnerabilities', 0))],
            ["Critical Vulnerabilities", str(data.get('risk_summary', {}).get('critical', 0))],
            ["High Risk Vulnerabilities", str(data.get('risk_summary', {}).get('high', 0))],
            ["Medium Risk Vulnerabilities", str(data.get('risk_summary', {}).get('medium', 0))],
            ["Low Risk Vulnerabilities", str(data.get('risk_summary', {}).get('low', 0))]
        ]

        summary_table = Table(summary)
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        story.append(summary_table)
        story.append(Spacer(1, 20))

        # Detailed Findings
        for result in data.get('analysis_results', []):
            service_info = result['service_info']
            vulns = result['vulnerabilities']

            # Service Information
            service_header = Paragraph(
                f"Service: {service_info['service']} ({service_info['ip']}:{service_info['port']})",
                self.styles['Heading2']
            )
            story.append(service_header)
            story.append(Spacer(1, 12))

            for vuln in vulns:
                vuln_data = [
                    ["Vulnerability", vuln['name']],
                    ["Risk Level", vuln['risk_level']],
                    ["CVE ID", vuln['cve_id']],
                    ["Description", vuln['description']]
                ]

                vuln_table = Table(vuln_data, colWidths=[100, 400])
                vuln_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
                    ('TEXTCOLOR', (0, 0), (0, -1), colors.black),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 10),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                story.append(vuln_table)
                story.append(Spacer(1, 12))

            # Remediation Steps
            if result.get('patch_steps'):
                steps_header = Paragraph("Remediation Steps:", self.styles['Heading3'])
                story.append(steps_header)
                for step in result['patch_steps']:
                    step_para = Paragraph(step, self.styles['Normal'])
                    story.append(step_para)
                story.append(Spacer(1, 12))

        # Generate PDF
        doc.build(story)
        return output_path

    def generate_html_report(self, data: Dict) -> str:
        """Generate an HTML report from vulnerability analysis data."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Vulnerability Analysis Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ background-color: #f8f9fa; padding: 20px; margin-bottom: 20px; }}
                .summary {{ margin-bottom: 30px; }}
                .vulnerability {{ border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; }}
                .risk-high {{ border-left: 5px solid #dc3545; }}
                .risk-medium {{ border-left: 5px solid #ffc107; }}
                .risk-low {{ border-left: 5px solid #28a745; }}
                .timestamp {{ color: #666; font-size: 0.9em; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Vulnerability Analysis Report</h1>
                <p class="timestamp">Generated on: {timestamp}</p>
            </div>

            <div class="summary">
                <h2>Summary</h2>
                <p>Total Vulnerabilities: {data.get('total_vulnerabilities', 0)}</p>
                <p>Critical: {data.get('risk_summary', {}).get('critical', 0)}</p>
                <p>High: {data.get('risk_summary', {}).get('high', 0)}</p>
                <p>Medium: {data.get('risk_summary', {}).get('medium', 0)}</p>
                <p>Low: {data.get('risk_summary', {}).get('low', 0)}</p>
            </div>
        """

        for result in data.get('analysis_results', []):
            service_info = result['service_info']
            html += f"""
            <div class="service-section">
                <h2>Service: {service_info['service']}</h2>
                <p>Location: {service_info['ip']}:{service_info['port']}</p>
                <p>Version: {service_info['version']}</p>
            """

            for vuln in result['vulnerabilities']:
                risk_class = f"risk-{vuln['risk_level'].lower()}"
                html += f"""
                <div class="vulnerability {risk_class}">
                    <h3>{vuln['name']}</h3>
                    <p><strong>Risk Level:</strong> {vuln['risk_level']}</p>
                    <p><strong>CVE ID:</strong> {vuln['cve_id']}</p>
                    <p><strong>Description:</strong> {vuln['description']}</p>
                    <div class="remediation">
                        <h4>Remediation Steps:</h4>
                        <ul>
                """
                
                for step in result.get('patch_steps', []):
                    html += f"<li>{step}</li>"
                
                html += """
                        </ul>
                    </div>
                </div>
                """
            
            html += "</div>"

        html += """
        </body>
        </html>
        """
        
        return html
